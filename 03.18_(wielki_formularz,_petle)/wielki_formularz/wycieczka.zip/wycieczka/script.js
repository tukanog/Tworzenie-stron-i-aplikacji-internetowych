function qs(s) { return document.querySelector(s) }
function qsa(s) { return document.querySelectorAll(s) }
function cl(i) { console.log(i) }

const WYCZIECZKA = qs('#wycieczka')
const POBYT = qs('#pobyt')
const POBYT_OUTPUT = qs('#pobyt_output')

POBYT_OUTPUT.innerHTML = POBYT.value * 5

POBYT.oninput = function() { POBYT_OUTPUT.innerHTML = POBYT.value * 5 }

WYCZIECZKA.onsubmit = function(e) {
    e.preventDefault()
}