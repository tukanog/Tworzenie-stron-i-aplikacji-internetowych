function qs(s) { return document.querySelector(s) }

const AKAPIT = qs('p')
const FONT_FAMILY = qs('#fontFamily')
const FONT_SIZE = qs('#fontSize')
const FONT_SIZE_OUTPUT = qs('#fontSizeOutput')
const COLOR = qs('#color')
const BACKGROUND_COLOR = qs('#backgroundColor')
const FONT_WEIGHT = qs('#fontWeight')
const FONT_STYLE = qs('#fontStyle')
const TEXT_DECORATION = qs('#textDecoration')
const ALIGN = document.querySelectorAll('.align')
const TEXT_TRANSFORM = qs('#textTransform')
const TEXT = qs('#text')

const DEFAULT_TEXT = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo impedit voluptas porro eligendi id quas modi debitis asperiores at magni esse nesciunt, commodi autem excepturi eveniet perspiciatis numquam repudiandae odit.'


// this w większości zdarzeń odnosi się do elementu który wywołał zdarzenie
// wyjątkiem jest onsubmit, dlatego musimy używać w nim e i e.target
// uwaga: this nie zadziała poprawnie w funkcji strzałkowej
