// Zad 1: temperatura
// napisz funkcję do obsługi formularza
// Wzory: K = C + 273.15 ; F = (C * 1.8) + 32


// Zad 2: faktura
// opracuj formularz dla poniższej funkcji - dobierz optymalne typy pól
/**
 * Funkcja oblicza koszt całkowity zakupu produktu 
 * 
 * @param {number} cena cena za kilogram
 * @param {number} waga waga produktu w kilogramach
 * @param {number} rabat rabat 0, 10 lub 20%
 */
function obliczCalkowityKoszt(cena, waga, rabat) {
    const KOSZT_BAZOWY = cena * waga
    const KOSZT_CALKOWITY = KOSZT_BAZOWY * (1 + rabat)

    return KOSZT_CALKOWITY
}

// Zad 3: Zapas paliwa
// Stwórz i obsłuż formularz obliczający zapas paliwa
// potrzebny do przejechania danej trasy
// wzór: (trasa[km] * spalanie[l/km]) / 100