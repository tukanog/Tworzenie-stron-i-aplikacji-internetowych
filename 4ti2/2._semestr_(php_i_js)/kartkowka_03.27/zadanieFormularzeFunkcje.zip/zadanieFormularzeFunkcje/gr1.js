// Zad 1: kantor
// napisz funkcję do obsługi formularza
// kurs dla poszczególnych walut: 1PLN = 0.23EUR = 0.27USD = 0.20GBP


// Zad 2: faktura
// opracuj formularz dla poniższej funkcji - dobierz optymalne typy pól
/**
 * Funkcja oblicza koszt całkowity zakupu produktu 
 * 
 * @param {number} cena cena za kilogram
 * @param {number} waga waga produktu w kilogramach
 * @param {number} rabat rabat 0, 10 lub 20%
 */
function obliczCalkowityKoszt(cena, waga, rabat) {
    const KOSZT_BAZOWY = cena * waga
    const KOSZT_CALKOWITY = KOSZT_BAZOWY * (1 + rabat)

    return KOSZT_CALKOWITY
}

// Zad 3: BMI
// Stwórz i obsłuż formularz obliczający BMI
// wzór: (waga[kg] / wzrost[cm] ** 2) * 10000